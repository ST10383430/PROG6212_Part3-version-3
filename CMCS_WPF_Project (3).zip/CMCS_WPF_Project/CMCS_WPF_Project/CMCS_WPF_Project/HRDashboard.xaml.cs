﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace CMCS_WPF_Project
{
    public partial class HRDashboard : Window
    {
        private List<Claim> hrClaims;

        public HRDashboard()
        {
            InitializeComponent();
            LoadHRClaims();
        }

        private void LoadHRClaims()
        {
            // Load claims from a mock data source or database
            hrClaims = new List<Claim>
            {
                new Claim { ClaimId = 1, HoursWorked = 10, HourlyRate = 350, TotalAmount = 3500, HRStatus = "Pending" },
                new Claim { ClaimId = 2, HoursWorked = 8, HourlyRate = 350, TotalAmount = 2800, HRStatus = "Pending" }
            };

            HRClaimsListView.ItemsSource = hrClaims;
        }

        private void GenerateInvoiceButton_Click(object sender, RoutedEventArgs e)
        {
            if (HRClaimsListView.SelectedItem is Claim selectedClaim)
            {
                // Generate invoice for the selected claim
                if (selectedClaim.HRStatus == "Approved")
                {
                    string invoiceContent = GenerateInvoiceContent(selectedClaim);

                    // Save the invoice to a file (example path used here)
                    string invoicePath = $"Invoice_{selectedClaim.ClaimId}_{DateTime.Now:yyyyMMddHHmmss}.txt";
                    System.IO.File.WriteAllText(invoicePath, invoiceContent);

                    MessageBox.Show($"Invoice generated successfully.\nSaved at: {invoicePath}", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("Only approved claims can have invoices generated.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            else
            {
                MessageBox.Show("Please select a claim to generate an invoice.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private string GenerateInvoiceContent(Claim claim)
        {
            return $"Invoice ID: {claim.ClaimId}\n" +
                   $"Hours Worked: {claim.HoursWorked}\n" +
                   $"Hourly Rate: {claim.HourlyRate:C}\n" +
                   $"Total Amount: {claim.TotalAmount:C}\n" +
                   $"Status: {claim.HRStatus}\n" +
                   $"Generated On: {DateTime.Now}";
        }

        private void ReturnToMainButton_Click(object sender, RoutedEventArgs e)
        {
            MainDashboard mainDashboard = new MainDashboard();
            mainDashboard.Show();
            this.Close();
        }
    }
}
