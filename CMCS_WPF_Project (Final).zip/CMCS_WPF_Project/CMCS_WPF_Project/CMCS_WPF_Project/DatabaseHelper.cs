﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMCS_WPF_Project
{
    internal class DatabaseHelper
    {
    }
}
