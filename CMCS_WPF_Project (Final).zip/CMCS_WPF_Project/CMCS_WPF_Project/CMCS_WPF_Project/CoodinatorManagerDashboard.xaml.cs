﻿using System.Collections.Generic;
using System.Windows;

namespace CMCS_WPF_Project
{
    public partial class CoordinatorDashboard : Window
    {
        public CoordinatorDashboard()
        {
            InitializeComponent();
            LoadClaims();
        }

        public void LoadClaims()
        {
            // Example: Loading claims (this would typically come from a database or service)
            var claims = new List<Claim>
            {
                new Claim { HoursWorked = 10, HourlyRate = 350, Notes = "Lecture preparation", Status = "Pending" },
                new Claim { HoursWorked = 8, HourlyRate = 350, Notes = "Marking papers", Status = "Approved" },
                new Claim { HoursWorked = 25, HourlyRate = 350, Notes = "Overreported hours", Status = "Pending" } // Example invalid claim
            };

            // Automated rejection of claims where HoursWorked > 24
            foreach (var claim in claims)
            {
                if (claim.HoursWorked > 24)
                {
                    claim.Status = "Rejected";
                    claim.Notes += " (Auto-Rejected: Exceeded 24 hours)";
                }
            }

            ClaimsListView.ItemsSource = claims;
        }

        private void ReturnToMainButton_Click(object sender, RoutedEventArgs e)
        {
            MainDashboard mainDashboard = new MainDashboard();
            mainDashboard.Show();
            this.Close(); // Close the coordinator dashboard window after returning to the main dashboard
        }

        public void ApproveButton_Click(object sender, RoutedEventArgs e)
        {
            if (ClaimsListView.SelectedItem is Claim selectedClaim)
            {
                if (selectedClaim.Status == "Rejected")
                {
                    MessageBox.Show("This claim cannot be approved as it was auto-rejected.");
                }
                else
                {
                    selectedClaim.Status = "Approved";
                    MessageBox.Show("Claim approved.");
                    ClaimsListView.Items.Refresh();
                }
            }
            else
            {
                MessageBox.Show("Please select a claim.");
            }
        }

        public void RejectButton_Click(object sender, RoutedEventArgs e)
        {
            if (ClaimsListView.SelectedItem is Claim selectedClaim)
            {
                selectedClaim.Status = "Rejected";
                MessageBox.Show("Claim rejected.");
                ClaimsListView.Items.Refresh();
            }
            else
            {
                MessageBox.Show("Please select a claim.");
            }
        }
    }

    
    
}
