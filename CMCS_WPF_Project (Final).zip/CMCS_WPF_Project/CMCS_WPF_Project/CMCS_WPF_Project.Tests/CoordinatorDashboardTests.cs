﻿using System.Collections.Generic;
using System.Security.Claims;
using System.Windows;
using Xunit;

namespace CMCS_WPF_Project.Tests
{
    public class CoordinatorDashboardTests
    {
        [Fact]
        public void ApproveButton_Click_ShouldUpdateClaimStatusToApproved()
        {
            // Arrange
            var coordinatorDashboard = new CoordinatorDashboard();
            var claim = new Claim { HoursWorked = 10, HourlyRate = 350, Notes = "Test claim", Status = "Pending" };
         //   coordinatorDashboard.ClaimsListView.Items.Add(claim);
         //   coordinatorDashboard.ClaimsListView.SelectedItem = claim;

            // Act
            coordinatorDashboard.ApproveButton_Click(null, null);

            // Assert
            Assert.Equal("Approved", claim.Status);
        }

        [Fact]
        public void RejectButton_Click_ShouldUpdateClaimStatusToRejected()
        {
            // Arrange
            var coordinatorDashboard = new CoordinatorDashboard();
            var claim = new Claim { HoursWorked = 8, HourlyRate = 350, Notes = "Test claim", Status = "Pending" };
          //  coordinatorDashboard.ClaimsListView.Items.Add(claim);
         //   coordinatorDashboard.ClaimsListView.SelectedItem = claim;

            // Act
            coordinatorDashboard.RejectButton_Click(null, null);

            // Assert
            Assert.Equal("Rejected", claim.Status);
        }

        [Fact]
        public void ApproveButton_Click_ShouldShowMessage_WhenNoClaimIsSelected()
        {
            // Arrange
            var coordinatorDashboard = new CoordinatorDashboard();
     //       coordinatorDashboard.ClaimsListView.SelectedItem = null;

            // Act
            coordinatorDashboard.ApproveButton_Click(null, null);

            // Assert
            // You can use a mocking library to verify that the message box was called,
            // or you can implement a way to capture the message box output for testing.
        }

        [Fact]
        public void RejectButton_Click_ShouldShowMessage_WhenNoClaimIsSelected()
        {
            // Arrange
            var coordinatorDashboard = new CoordinatorDashboard();
      //      coordinatorDashboard.ClaimsListView.SelectedItem = null;

            // Act
            coordinatorDashboard.RejectButton_Click(null, null);

            // Assert
            // Again, verify the message box output as needed.
        }
    }
}
