﻿using System.Windows;

namespace CMCS_WPF_Project
{
    public partial class CoordinatorDashboard : Window
    {
        public CoordinatorDashboard()
        {
            InitializeComponent();
            LoadClaims();
        }

        public void LoadClaims()
        {
            // Example: Loading claims (this would typically come from a database or service)
            var claims = new List<Claim>
            {
                new Claim { HoursWorked = 10, HourlyRate = 350, Notes = "Lecture preparation", Status = "Pending" },
                new Claim { HoursWorked = 8, HourlyRate = 350, Notes = "Marking papers", Status = "Pending" }
            };

            ClaimsListView.ItemsSource = claims;
        }

        private void ReturnToMainButton_Click(object sender, RoutedEventArgs e)
        {
            MainDashboard mainDashboard = new MainDashboard();
            mainDashboard.Show();
            this.Close(); // Close the coordinator dashboard window after returning to the main dashboard
        }


        public void ApproveButton_Click(object sender, RoutedEventArgs e)
        {
            if (ClaimsListView.SelectedItem is Claim selectedClaim)
            {
                selectedClaim.Status = "Approved";
                MessageBox.Show("Claim approved.");
                ClaimsListView.Items.Refresh();
            }
            else
            {
                MessageBox.Show("Please select a claim.");
            }
        }

        public void RejectButton_Click(object sender, RoutedEventArgs e)
        {
            if (ClaimsListView.SelectedItem is Claim selectedClaim)
            {
                selectedClaim.Status = "Rejected";
                MessageBox.Show("Claim rejected.");
                ClaimsListView.Items.Refresh();
            }
            else
            {
                MessageBox.Show("Please select a claim.");
            }
        }
    }
}