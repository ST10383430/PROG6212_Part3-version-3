﻿using System.Windows;

namespace CMCS_WPF_Project
{
    public partial class MainDashboard : Window
    {
        public MainDashboard()
        {
            InitializeComponent();
        }

        private void LecturerButton_Click(object sender, RoutedEventArgs e)
        {
            LecturerDashboard lecturerDashboard = new LecturerDashboard();
            lecturerDashboard.Show();
            this.Close(); // Close the main dashboard window
        }

        private void CoordinatorButton_Click(object sender, RoutedEventArgs e)
        {
            CoordinatorDashboard coordinatorDashboard = new CoordinatorDashboard();
            coordinatorDashboard.Show();
            this.Close(); // Close the main dashboard window
        }

        private void HRButton_Click(object sender, RoutedEventArgs e)
        {
            HRDashboard hrDashboard = new HRDashboard();
            hrDashboard.Show();
            this.Close(); // Close the main window after navigating to the HR dashboard
        }
    }
}
