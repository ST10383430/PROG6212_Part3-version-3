﻿using System.Linq;
using System.Security.Claims;
using System.Windows;

namespace CMCS_WPF_Project
{
    public partial class HRDashboard : Window
    {
        private CMCSDbContext _context;

        public HRDashboard()
        {
            InitializeComponent();
            _context = new CMCSDbContext();
            LoadClaims();
        }

        private void LoadClaims()
        {
            var claims = _context.Claims.Where(c => c.Status == "Approved" && c.HRStatus == "Pending").ToList();
            ClaimsListView.ItemsSource = claims;
        }

        private void FinalizeButton_Click(object sender, RoutedEventArgs e)
        {
            if (ClaimsListView.SelectedItem is Claim selectedClaim)
            {
                selectedClaim.HRStatus = "Finalized";
                selectedClaim.Status = "Completed";  // Finalized claim
                _context.SaveChanges();
                MessageBox.Show("Claim finalized.");
                ClaimsListView.Items.Refresh();
            }
            else
            {
                MessageBox.Show("Please select a claim.");
            }
        }

        private void ReturnToMainButton_Click(object sender, RoutedEventArgs e)
        {
            MainDashboard mainDashboard = new MainDashboard();
            mainDashboard.Show();
            this.Close(); // Close the HR dashboard window after returning to the main dashboard
        }
    }
}
