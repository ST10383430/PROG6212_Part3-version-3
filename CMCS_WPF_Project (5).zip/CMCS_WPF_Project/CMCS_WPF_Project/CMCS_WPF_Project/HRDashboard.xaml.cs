﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace CMCS_WPF_Project
{
    public partial class HRDashboard : Window
    {
        private List<Claim> hrClaims;
        private List<Lecturer> lecturers;
        public HRDashboard()
        {
            InitializeComponent();
            LoadHRClaims();
            LoadLecturers();
        }

        private void LoadHRClaims()
        {
            // Load claims from a mock data source or database
            hrClaims = new List<Claim>
            {
                new Claim { ClaimId = 1,  HoursWorked = 10, HourlyRate = 350, TotalAmount = 3500, HRStatus = "Pending" },
                new Claim { ClaimId = 2, HoursWorked = 8, HourlyRate = 350, TotalAmount = 2800, HRStatus = "Approved" }
            };

            HRClaimsListView.ItemsSource = hrClaims;
        }

        private void LoadLecturers()
        {
            lecturers = new List<Lecturer>
            {
                new Lecturer { Id = 1, Name = "John Doe", Contact = "1234567890", Email = "johndoe@example.com" },
                new Lecturer { Id = 2, Name = "Jane Smith", Contact = "0987654321", Email = "janesmith@example.com" }
            };

            LecturerComboBox.ItemsSource = lecturers;
            LecturerComboBox.DisplayMemberPath = "Name";
        }

        private void LecturerComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (LecturerComboBox.SelectedItem is Lecturer selectedLecturer)
            {
                LecturerNameTextBox.Text = selectedLecturer.Name;
                LecturerContactTextBox.Text = selectedLecturer.Contact;
                LecturerEmailTextBox.Text = selectedLecturer.Email;
            }
        }

        private void UpdateLecturerButton_Click(object sender, RoutedEventArgs e)
        {
            if (LecturerComboBox.SelectedItem is Lecturer selectedLecturer)
            {
                selectedLecturer.Name = LecturerNameTextBox.Text;
                selectedLecturer.Contact = LecturerContactTextBox.Text;
                selectedLecturer.Email = LecturerEmailTextBox.Text;

                MessageBox.Show("Lecturer details updated successfully.", "Update Successful", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void ApproveClaimButton_Click(object sender, RoutedEventArgs e)
        {
            if (HRClaimsListView.SelectedItem is Claim selectedClaim)
            {
                selectedClaim.HRStatus = "Approved";
                MessageBox.Show("Claim approved.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                HRClaimsListView.Items.Refresh();
            }
        }

        private void RejectClaimButton_Click(object sender, RoutedEventArgs e)
        {
            if (HRClaimsListView.SelectedItem is Claim selectedClaim)
            {
                selectedClaim.HRStatus = "Rejected";
                MessageBox.Show("Claim rejected.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                HRClaimsListView.Items.Refresh();
            }
        }


        private void GenerateInvoiceButton_Click(object sender, RoutedEventArgs e)
        {
            if (HRClaimsListView.SelectedItem is Claim selectedClaim)
            {
                // Generate invoice for the selected claim
                if (selectedClaim.HRStatus == "Approved")
                {
                    string invoiceContent = GenerateInvoiceContent(selectedClaim);

                    // Save the invoice to a file (example path used here)
                    string invoicePath = $"Invoice_{selectedClaim.ClaimId}_{DateTime.Now:yyyyMMddHHmmss}.txt";
                    System.IO.File.WriteAllText(invoicePath, invoiceContent);

                    MessageBox.Show($"Invoice generated successfully.\nSaved at: {invoicePath}", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("Only approved claims can have invoices generated.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            else
            {
                MessageBox.Show("Please select a claim to generate an invoice.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private string GenerateInvoiceContent(Claim claim)
        {
            return $"Invoice ID: {claim.ClaimId}\n" +
                   $"Hours Worked: {claim.HoursWorked}\n" +
                   $"Hourly Rate: {claim.HourlyRate:C}\n" +
                   $"Total Amount: {claim.TotalAmount:C}\n" +
                   $"Status: {claim.HRStatus}\n" +
                   $"Generated On: {DateTime.Now}";
        }

        private void ReturnToMainButton_Click(object sender, RoutedEventArgs e)
        {
            MainDashboard mainDashboard = new MainDashboard();
            mainDashboard.Show();
            this.Close();
        }
    }
}
