﻿using Microsoft.EntityFrameworkCore;
using System.Linq;
namespace CMCS_WPF_Project
{
    public class CMCSDbContext : DbContext
    {
        public static object HRClaims { get; internal set; }
       
        public DbSet<Claim> Claims { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
           // optionsBuilder.UseSqlServer(@"Server=(localdb)\mssqllocaldb;Database=CMCS_DB;Trusted_Connection=True;");
        }
    }
}
