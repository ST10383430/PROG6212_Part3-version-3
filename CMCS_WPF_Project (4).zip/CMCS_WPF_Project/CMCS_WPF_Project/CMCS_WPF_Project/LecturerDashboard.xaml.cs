﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Linq;

namespace CMCS_WPF_Project
{
    public partial class LecturerDashboard : Window
    {
        private string uploadedFilePath;
        private List<Claim> claims = new List<Claim>();

        public LecturerDashboard()
        {
            InitializeComponent();
        }

        private void SubmitClaimButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int hoursWorked;

                if (!int.TryParse(HoursWorkedTextBox.Text, out hoursWorked) || hoursWorked <= 0)
                {
                    HoursWorkedError.Visibility = Visibility.Visible;
                    return;
                }
                HoursWorkedError.Visibility = Visibility.Collapsed;

                decimal hourlyRate;

                if (!decimal.TryParse(HourlyRateTextBox.Text, out hourlyRate) || hourlyRate <= 0)
                {
                    HourlyRateError.Visibility = Visibility.Visible;
                    return;
                }
                HourlyRateError.Visibility = Visibility.Collapsed;

                string additionalNotes = AdditionalNotesTextBox.Text;

                if (string.IsNullOrWhiteSpace(uploadedFilePath))
                {
                    DocumentError.Visibility = Visibility.Visible;
                    return;
                }
                DocumentError.Visibility = Visibility.Collapsed;

                var claim = new Claim
                {
                    HoursWorked = hoursWorked,
                    HourlyRate = hourlyRate,
                    Notes = additionalNotes,
                    FilePath = uploadedFilePath,
                    Status = "Pending", 
                    HRStatus = "Pending"
                };
                claims.Add(claim);

                ClaimStatusText.Text = $"Claim submitted! Status: {claim.Status}";
                HoursWorkedTextBox.Clear();
                HourlyRateTextBox.Clear();
                AdditionalNotesTextBox.Clear();
                lblTotal.Text = "Total: $0.00";
                DocumentUploadStatus.Text = "No file selected";
                uploadedFilePath = null;

                MessageBox.Show("Claim submitted successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error submitting claim: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ReturnToMainButton_Click(object sender, RoutedEventArgs e)
        {
            MainDashboard mainDashboard = new MainDashboard();
            mainDashboard.Show();
            this.Close();
        }

        private void UploadDocumentButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog
                {
                    Filter = "PDF files (*.pdf)|*.pdf|Word Documents (*.docx)|*.docx|Excel Files (*.xlsx)|*.xlsx",
                    Title = "Select a document"
                };

                if (openFileDialog.ShowDialog() == true)
                {
                    uploadedFilePath = openFileDialog.FileName;
                    DocumentUploadStatus.Text = $"File: {Path.GetFileName(uploadedFilePath)}";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error uploading document: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void UpdateLecturerInfoButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string lecturerName = LecturerNameTextBox.Text.Trim();
                string lecturerContact = LecturerContactTextBox.Text.Trim();

                if (string.IsNullOrWhiteSpace(lecturerName))
                {
                    LecturerNameError.Visibility = Visibility.Visible;
                    return;
                }
                LecturerNameError.Visibility = Visibility.Collapsed;

                if (string.IsNullOrWhiteSpace(lecturerContact) || !lecturerContact.All(char.IsDigit))
                {
                    LecturerContactError.Visibility = Visibility.Visible;
                    return;
                }
                LecturerContactError.Visibility = Visibility.Collapsed;

                // Assume a Lecturer object or database update logic here
                MessageBox.Show("Lecturer information updated successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating lecturer information: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void NavigateToHRDashboard_Click(object sender, RoutedEventArgs e)
        {
            HRDashboard hrDashboard = new HRDashboard();
            hrDashboard.Show();
            this.Close();
        }



        private void InputFields_TextChanged(object sender, TextChangedEventArgs e)
        {
            CalculateTotal();
        }

        private void CalculateTotal()
        {
            if (double.TryParse(HoursWorkedTextBox.Text, out double hours) &&
                double.TryParse(HourlyRateTextBox.Text, out double rate))
            {
                double totalPayment = hours * rate;
                lblTotal.Text = $"Total: {totalPayment:C2}";
            }
            else
            {
                lblTotal.Text = "Total: $0.00";
            }
        }

        public void DisplayClaimStatus(int claimId)
        {
            var hrClaim = claims.FirstOrDefault(c => c.ClaimId == claimId);

            if (hrClaim != null)
            {
                ClaimStatusText.Text = $"Processed by HR. Status: {hrClaim.HRStatus}, Total Amount: {hrClaim.TotalAmount:C}";
            }
            else
            {
                ClaimStatusText.Text = "No claim processed by HR yet.";
            }
        }

    }

    public class Claim
    {
        public int ClaimId { get; set; }
        public int HoursWorked { get; set; }
        public decimal HourlyRate { get; set; }
        public decimal TotalAmount { get; set; } 
        public string Notes { get; set; }
        public string FilePath { get; set; }
        public string Status { get; set; }
        public string HRStatus { get; set; }
    }

}
